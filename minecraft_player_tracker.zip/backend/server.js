const express = require("express");
const mysql = require("mysql2");

const app = express();
app.use(express.json());

const API_KEY = "SUPER_SECRET_KEY_123";

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "minecraft"
});

function checkApiKey(req, res, next) {
  if (req.headers["x-api-key"] !== API_KEY) {
    return res.status(401).send("Unauthorized");
  }
  next();
}

app.post("/api/players", checkApiKey, (req, res) => {
  const { uuid, name, timestamp } = req.body;

  db.query("SELECT * FROM players WHERE uuid = ?", [uuid], (err, results) => {
    if (results.length === 0) {
      db.query(
        "INSERT INTO players (uuid, name, first_join, last_join) VALUES (?, ?, ?, ?)",
        [uuid, name, timestamp, timestamp]
      );
    } else {
      db.query(
        "UPDATE players SET name=?, last_join=? WHERE uuid=?",
        [name, timestamp, uuid]
      );
    }
  });

  res.sendStatus(200);
});

app.listen(3000, () => console.log("Server läuft auf Port 3000"));
