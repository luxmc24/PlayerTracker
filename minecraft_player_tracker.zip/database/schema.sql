CREATE DATABASE minecraft;
USE minecraft;

CREATE TABLE players (
  uuid VARCHAR(36) PRIMARY KEY,
  name VARCHAR(50),
  first_join BIGINT,
  last_join BIGINT
);
