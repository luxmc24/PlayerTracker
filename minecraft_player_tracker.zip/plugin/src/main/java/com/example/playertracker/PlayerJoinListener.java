package com.example.playertracker;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        var p = e.getPlayer();

        String json = "{"
                + "\"uuid\":\"" + p.getUniqueId() + "\","
                + "\"name\":\"" + p.getName() + "\","
                + "\"event\":\"join\","
                + "\"timestamp\":" + System.currentTimeMillis()
                + "}";

        ApiClient.send(json);
    }
}
