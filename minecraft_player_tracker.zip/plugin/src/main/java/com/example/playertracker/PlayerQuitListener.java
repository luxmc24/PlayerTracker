package com.example.playertracker;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        var p = e.getPlayer();

        String json = "{"
                + "\"uuid\":\"" + p.getUniqueId() + "\","
                + "\"name\":\"" + p.getName() + "\","
                + "\"event\":\"quit\","
                + "\"timestamp\":" + System.currentTimeMillis()
                + "}";

        ApiClient.send(json);
    }
}
