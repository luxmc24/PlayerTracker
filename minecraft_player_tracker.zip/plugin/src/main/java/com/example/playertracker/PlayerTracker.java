package com.example.playertracker;

import org.bukkit.plugin.java.JavaPlugin;

public class PlayerTracker extends JavaPlugin {

    private static PlayerTracker instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        getServer().getPluginManager().registerEvents(new PlayerJoinListener(), this);
        getServer().getPluginManager().registerEvents(new PlayerQuitListener(), this);
    }

    public static PlayerTracker getInstance() {
        return instance;
    }
}
