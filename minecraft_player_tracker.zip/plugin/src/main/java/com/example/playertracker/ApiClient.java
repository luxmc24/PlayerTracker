package com.example.playertracker;

import org.bukkit.Bukkit;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {

    public static void send(String json) {
        Bukkit.getScheduler().runTaskAsynchronously(
                PlayerTracker.getInstance(),
                () -> {
                    try {
                        String apiUrl = PlayerTracker.getInstance().getConfig().getString("api.url");
                        String apiKey = PlayerTracker.getInstance().getConfig().getString("api.key");

                        HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Content-Type", "application/json");
                        conn.setRequestProperty("X-API-Key", apiKey);
                        conn.setDoOutput(true);

                        try (OutputStream os = conn.getOutputStream()) {
                            os.write(json.getBytes(StandardCharsets.UTF_8));
                        }

                        conn.getResponseCode();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
        );
    }
}
